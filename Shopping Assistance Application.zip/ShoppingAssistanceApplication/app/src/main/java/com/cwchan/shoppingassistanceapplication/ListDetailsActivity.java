package com.cwchan.shoppingassistanceapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class ListDetailsActivity extends AppCompatActivity {
//  Variable declaration
    TextView tvEmptyListDetailsMessage;
    EditText etItemName, etDescription, etPrice, etQuantity;
    AutoCompleteTextView etLocation;
    Button btnPlus, btnMinus, btnSave, btnCancel, btnShowMap;
    ListView lvListDetails;
    ArrayList<String> itemId, itemlist, itemQuantity, itemTotalPrice, itemCompleted;
    Dialog addCheckListItemDialog, editCheckListItemDialog;
    DBHelper helper;
    SQLiteDatabase writeDB, readDB;
    String itemName, description, location;
    double price, totalPrice;
    int listId, quantity, pos=-1;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_details);

//      Get list id value from intent
        Intent myIntent = getIntent();
        listId = myIntent.getIntExtra("listid",0);

//      Associate adapter with the sample location array to provide suggestion when searching an item
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.sampleLocations));

//      Initialize the arraylist
        itemId = new ArrayList<>();
        itemlist = new ArrayList<>();
        itemQuantity = new ArrayList<>();
        itemTotalPrice = new ArrayList<>();
        itemCompleted = new ArrayList<>();

//      View association
        tvEmptyListDetailsMessage = findViewById(R.id.tvEmptyListDetailsMessage);
        lvListDetails = findViewById(R.id.lvListDetails);

//      To call the DBHelper class
        helper = new DBHelper(getApplicationContext());

//      To retrieve records from table to be added to the arraylist
        readDB = helper.getReadableDatabase();
        try {
            Cursor cursor = readDB.rawQuery("select * from listdetails where list_id=" + listId, null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    itemId.add(cursor.getString(0));
                    itemlist.add(cursor.getString(1));
                    price = Double.valueOf(cursor.getString(3));
                    quantity = Integer.valueOf(cursor.getString(4));
                    itemTotalPrice.add(String.valueOf(price * (double)quantity));
                    itemQuantity.add(String.valueOf(quantity));
                    itemCompleted.add(cursor.getString(6));
                }

                for(int i=0;i<itemId.size();i++)
                    totalPrice += Double.valueOf(itemTotalPrice.get(i));

                tvEmptyListDetailsMessage.setText("Total price for this checklist : "+totalPrice+"\nNumber of items by types : "+itemId.size());
            } else {
                tvEmptyListDetailsMessage.setText("Please click '+' on the top-right corner to add a new checklist!");
            }
        }catch (Exception e){
            tvEmptyListDetailsMessage.setText(e.getMessage());
        }

//      Set adapter to the listview
        lvListDetails.setAdapter(new MyAdapter(ListDetailsActivity.this));

//      Mark complete on the selected item when the listview is clicked
        lvListDetails.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                TextView tvItemName;
                tvItemName = view.findViewById(R.id.tvItemName);

                String message = "";

                writeDB = helper.getWritableDatabase();
                ContentValues contentValues = new ContentValues();

                if(itemCompleted.get(position).equals("No")) {
                    tvItemName.setPaintFlags(tvItemName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                    itemCompleted.set(position, "Yes");
                    contentValues.put("completed", "Yes");
                    message = "An item has been marked complete!";
                }
                else {
                    tvItemName.setPaintFlags(tvItemName.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                    itemCompleted.set(position, "No");
                    contentValues.put("completed", "No");
                    message = "An item has been marked incomplete!";
                }

                long rows = writeDB.update("listdetails", contentValues, "item_id=?", new String[]{itemId.get(position)});
                if(rows>0) {
                    Toast.makeText(ListDetailsActivity.this, message, Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(ListDetailsActivity.this, "Failed to update record!", Toast.LENGTH_LONG).show();
            }
        });

//      Register listview for context menu
        registerForContextMenu(lvListDetails);
    }

//  Create context menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.context_menu, menu);
        AdapterView.AdapterContextMenuInfo acmi = (AdapterView.AdapterContextMenuInfo) menuInfo;
        pos = acmi.position;
    }

//  Determine the action when an item in context menu is selected
    @Override
    public boolean onContextItemSelected(@NonNull final MenuItem item) {
        int option = item.getItemId();
        switch(option){
            case R.id.cm_edit:
//              Show edit dialog for the user to edit the item details
                readDB = helper.getReadableDatabase();
                Cursor cursor = readDB.rawQuery("select * from listdetails where item_id="+itemId.get(pos), null);
                if(cursor.getCount()>0){
                    while(cursor.moveToNext()){
                        itemName = cursor.getString(1);
                        description = cursor.getString(2);
                        price = cursor.getDouble(3);
                        quantity = cursor.getInt(4);
                        location = cursor.getString(7);
                    }
                }else {
                    Toast.makeText(ListDetailsActivity.this, "No record found!", Toast.LENGTH_LONG).show();
                }

                editCheckListItemDialog = new Dialog(ListDetailsActivity.this);
                editCheckListItemDialog.setContentView(R.layout.itemdetails_layout);

                etItemName = editCheckListItemDialog.findViewById(R.id.etItemName);
                etItemName.setText(itemName);

                etDescription = editCheckListItemDialog.findViewById(R.id.etDescription);
                etDescription.setText(description);

                etPrice = editCheckListItemDialog.findViewById(R.id.etPrice);
                etPrice.setText(String.valueOf(price));

                etQuantity = editCheckListItemDialog.findViewById(R.id.etQuantity);
                etQuantity.setText(String.valueOf(quantity));

                etLocation = editCheckListItemDialog.findViewById(R.id.etLocation);
                etLocation.setAdapter(adapter);
                etLocation.setText(location);
                btnShowMap = editCheckListItemDialog.findViewById(R.id.btnShowMap);
                btnShowMap.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri uri = Uri.parse("geo:0,0?q="+etLocation.getText().toString());
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(mapIntent);
                    }
                });

                btnSave = editCheckListItemDialog.findViewById(R.id.btnSave);
                btnSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        itemName = etItemName.getText().toString();
                        description = etDescription.getText().toString();
                        price = Double.valueOf(etPrice.getText().toString());
                        quantity = Integer.valueOf(etQuantity.getText().toString());
                        location = etLocation.getText().toString();

                        writeDB = helper.getWritableDatabase();
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("item_name", itemName);
                        contentValues.put("description", description);
                        contentValues.put("price", price);
                        contentValues.put("quantity", quantity);
                        contentValues.put("list_id", listId);
                        contentValues.put("location", location);
                        long rows = writeDB.update("listdetails", contentValues, "item_id=?", new String[]{itemId.get(pos)});
                        if(rows>0) {
                            Toast.makeText(ListDetailsActivity.this, "New item has been updated!", Toast.LENGTH_LONG).show();
                            itemlist.set(pos, itemName);
                            itemTotalPrice.set(pos, String.valueOf(price * (double)quantity));
                            itemQuantity.set(pos, String.valueOf(quantity));
                            lvListDetails.setAdapter(new MyAdapter(ListDetailsActivity.this));

                            totalPrice = 0;
                            for(int i=0;i<itemId.size();i++)
                                totalPrice += Double.valueOf(itemTotalPrice.get(i));

                            tvEmptyListDetailsMessage.setText("Total price for this checklist : "+totalPrice+"\nNumber of items by types : "+itemId.size());
                        }
                        else
                            Toast.makeText(ListDetailsActivity.this, "Failed to update record!", Toast.LENGTH_LONG).show();

                        editCheckListItemDialog.dismiss();
                    }
                });

                btnCancel = editCheckListItemDialog.findViewById(R.id.btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        editCheckListItemDialog.dismiss();
                    }
                });

//              Allow the user to increase the quantity of an item
                btnPlus = editCheckListItemDialog.findViewById(R.id.btnPlus);
                btnPlus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        quantity = Integer.valueOf(etQuantity.getText().toString());

                        if(quantity<100) {
                            quantity++;
                            etQuantity.setText("" + quantity);
                        }
                    }
                });

//              Allow the user to decrease the quantity of an item
                btnMinus = editCheckListItemDialog.findViewById(R.id.btnMinus);
                btnMinus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        quantity = Integer.valueOf(etQuantity.getText().toString());

                        if(quantity>1) {
                            quantity--;
                            etQuantity.setText("" + quantity);
                        }
                    }
                });

                editCheckListItemDialog.show();
                break;
//          Delete the selected item
            case R.id.cm_delete:
                AlertDialog deleteDialogBox = AskOption();
                deleteDialogBox.show();
                break;
        }
        return super.onContextItemSelected(item);
    }

//  Create option menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_mainmenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

//  Determine the action when an item in option menu is selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int option = item.getItemId();
        switch(option){
            case R.id.mm_add:
//              Show add dialog for the user to add new item
                quantity = 1;

                addCheckListItemDialog = new Dialog(ListDetailsActivity.this);
                addCheckListItemDialog.setContentView(R.layout.itemdetails_layout);

                etItemName = addCheckListItemDialog.findViewById(R.id.etItemName);
                etItemName.setText("Item "+(itemlist.size()+1));

                etDescription = addCheckListItemDialog.findViewById(R.id.etDescription);
                etPrice = addCheckListItemDialog.findViewById(R.id.etPrice);
                etPrice.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        etPrice.setText("");
                    }
                });

                etQuantity = addCheckListItemDialog.findViewById(R.id.etQuantity);

                etLocation = addCheckListItemDialog.findViewById(R.id.etLocation);
                etLocation.setAdapter(adapter);
                btnShowMap = addCheckListItemDialog.findViewById(R.id.btnShowMap);
                btnShowMap.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri uri = Uri.parse("geo:0,0?q="+etLocation.getText().toString());
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(mapIntent);
                    }
                });

                btnSave = addCheckListItemDialog.findViewById(R.id.btnSave);
                btnSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        itemName = etItemName.getText().toString();
                        description = etDescription.getText().toString();
                        price = Double.valueOf(etPrice.getText().toString());
                        quantity = Integer.valueOf(etQuantity.getText().toString());
                        location = etLocation.getText().toString();

                        writeDB = helper.getWritableDatabase();
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("item_name", itemName);
                        contentValues.put("description", description);
                        contentValues.put("price", price);
                        contentValues.put("quantity", quantity);
                        contentValues.put("list_id", listId);
                        contentValues.put("completed", "No");
                        contentValues.put("location", location);
                        long rows = writeDB.insert("listdetails", null, contentValues);
                        if(rows>0) {
                            Toast.makeText(ListDetailsActivity.this, "New item has been added!", Toast.LENGTH_LONG).show();
                            itemlist.add(itemName);
                            itemTotalPrice.add(String.valueOf(price * (double)quantity));
                            itemQuantity.add(String.valueOf(quantity));
                            itemCompleted.add("No");
                            lvListDetails.setAdapter(new MyAdapter(ListDetailsActivity.this));

                            totalPrice = 0;
                            for(int i=0;i<itemlist.size();i++)
                                totalPrice += Double.valueOf(itemTotalPrice.get(i));

                            tvEmptyListDetailsMessage.setText("Total price for this checklist : "+totalPrice+"\nNumber of items by types : "+itemlist.size());
                        }
                        else
                            Toast.makeText(ListDetailsActivity.this, "Failed to add record!", Toast.LENGTH_LONG).show();

                        itemId.clear();

                        Cursor cursor = readDB.rawQuery("select item_id from listdetails where list_id="+listId, null);
                        if(cursor.getCount()>0){
                            while(cursor.moveToNext()){
                                itemId.add(cursor.getString(0));
                            }
                        }else {
                            Toast.makeText(ListDetailsActivity.this, "No record found!", Toast.LENGTH_LONG).show();
                        }

                        addCheckListItemDialog.dismiss();
                    }
                });

                btnCancel = addCheckListItemDialog.findViewById(R.id.btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        addCheckListItemDialog.dismiss();
                    }
                });

                btnPlus = addCheckListItemDialog.findViewById(R.id.btnPlus);
                btnPlus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        quantity = Integer.valueOf(etQuantity.getText().toString());

                        if(quantity<100) {
                            quantity++;
                            etQuantity.setText("" + quantity);
                        }
                    }
                });

                btnMinus = addCheckListItemDialog.findViewById(R.id.btnMinus);
                btnMinus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        quantity = Integer.valueOf(etQuantity.getText().toString());

                        if(quantity>1) {
                            quantity--;
                            etQuantity.setText("" + quantity);
                        }
                    }
                });

                addCheckListItemDialog.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

//  Adapter View association
    public class MyAdapter extends BaseAdapter {

        Context context;
        public MyAdapter(Context context) {
            this.context = context;
        }

        @Override
        public int getCount() {
            return itemId.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final TextView tvItemName, tvQuantity, tvTotalPrice;
            Button btnMinus_lv, btnPlus_lv;
            if(convertView == null) {
                convertView = LayoutInflater.from(this.context).inflate(R.layout.listviewdetails_layout, parent, false);
            }
            tvItemName = convertView.findViewById(R.id.tvItemName);
            tvQuantity = convertView.findViewById(R.id.tvQuantity);
            tvTotalPrice = convertView.findViewById(R.id.tvTotalPrice);
            btnMinus_lv = convertView.findViewById(R.id.btnMinus_lv);
            btnPlus_lv = convertView.findViewById(R.id.btnPlus_lv);

            tvItemName.setText(itemlist.get(position));
            if(itemCompleted.get(position).equals("Yes"))
                tvItemName.setPaintFlags(tvItemName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            else
                tvItemName.setPaintFlags(tvItemName.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));

            tvQuantity.setText("Quantity : "+itemQuantity.get(position));
            tvTotalPrice.setText("Total Price : "+itemTotalPrice.get(position));

            btnMinus_lv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    quantity = Integer.valueOf(itemQuantity.get(position));
                    price = Double.valueOf(itemTotalPrice.get(position))/quantity;
                    if(quantity>1)
                        quantity--;

                    writeDB = helper.getWritableDatabase();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("quantity", quantity);
                    long rows = writeDB.update("listdetails", contentValues, "item_id=?", new String[]{itemId.get(position)});
                    if(rows>0) {
                        tvQuantity.setText("Quantity : "+quantity);
                        tvTotalPrice.setText("Total Price : "+(price*(double)quantity));
                        itemQuantity.set(position,String.valueOf(quantity));
                        itemTotalPrice.set(position,String.valueOf(price*(double)quantity));
                    }
                    else
                        Toast.makeText(ListDetailsActivity.this, "Failed to add record!", Toast.LENGTH_LONG).show();

                    totalPrice = 0;
                    for(int i=0;i<itemId.size();i++)
                        totalPrice += Double.valueOf(itemTotalPrice.get(i));

                    tvEmptyListDetailsMessage.setText("Total price for this checklist : "+totalPrice+"\nNumber of items by types : "+itemId.size());
                }
            });

            btnPlus_lv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    quantity = Integer.valueOf(itemQuantity.get(position));
                    price = Double.valueOf(itemTotalPrice.get(position))/quantity;
                    if(quantity<100)
                        quantity++;

                    writeDB = helper.getWritableDatabase();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("quantity", quantity);
                    long rows = writeDB.update("listdetails", contentValues, "item_id=?", new String[]{itemId.get(position)});
                    if(rows>0) {
                        tvQuantity.setText("Quantity : "+quantity);
                        tvTotalPrice.setText("Total Price : "+(price*(double)quantity));
                        itemQuantity.set(position,String.valueOf(quantity));
                        itemTotalPrice.set(position,String.valueOf(price*(double)quantity));
                    }
                    else
                        Toast.makeText(ListDetailsActivity.this, "Failed to add record!", Toast.LENGTH_LONG).show();

                    totalPrice = 0;
                    for(int i=0;i<itemId.size();i++)
                        totalPrice += Double.valueOf(itemTotalPrice.get(i));

                    tvEmptyListDetailsMessage.setText("Total price for this checklist : "+totalPrice+"\nNumber of items by types : "+itemId.size());
                }
            });

            return convertView;
        }
    }

//  Show delete confirmation dialog box
    private AlertDialog AskOption()
    {
        AlertDialog myQuittingDialogBox = new AlertDialog.Builder(this)
                // set message, title, and icon
                .setTitle("Delete")
                .setMessage("Do you want to Delete")

                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        writeDB = helper.getWritableDatabase();
                        long rowscount = writeDB.delete("listdetails", "item_id=?", new String[]{itemId.get(pos)});
                        if(rowscount>0) {
                            Toast.makeText(ListDetailsActivity.this, " Item has been deleted!", Toast.LENGTH_LONG).show();
                            itemId.remove(pos);
                            itemlist.remove(pos);
                            itemQuantity.remove(pos);
                            itemTotalPrice.remove(pos);
                            itemCompleted.remove(pos);
                            lvListDetails.setAdapter(new MyAdapter(ListDetailsActivity.this));

                            totalPrice = 0;
                            for(int i=0;i<itemId.size();i++)
                                totalPrice += Double.valueOf(itemTotalPrice.get(i));

                            tvEmptyListDetailsMessage.setText("Total price for this checklist : "+totalPrice+"\nNumber of items by types : "+itemId.size());
                        }

                        if(itemId.size()<=0)
                            tvEmptyListDetailsMessage.setText("Please click '+' on the top-right corner to add a new checklist!");

                        dialog.dismiss();
                    }

                })
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();

                    }
                })
                .create();

        return myQuittingDialogBox;
    }
}
