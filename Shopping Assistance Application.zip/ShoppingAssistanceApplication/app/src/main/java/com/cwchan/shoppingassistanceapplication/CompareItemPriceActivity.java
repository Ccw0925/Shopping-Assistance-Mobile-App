package com.cwchan.shoppingassistanceapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CompareItemPriceActivity extends AppCompatActivity {

//  Variables declaration
    AutoCompleteTextView etSearchItem;
    ListView lvSearchList;
    ArrayList<String> itemId, itemList, itemPrice, itemLocation, listId, listName, uniqueListId, uniqueListName, autoCompleteitemList, autoCompleteLocationList;
    ArrayAdapter adapter, searchAdapter;
    DBHelper helper;
    SQLiteDatabase readDB, writeDB;
    Dialog searchItemDetailDialog;
    TextView tvSearchItemNameDetails, tvSearchItemPriceDetails, tvSearchItemLocationDetails;
    Button btnShowMapSearchDetails, btnAddExistingList, btnCancelSearchItemDetails;
    String location;
    Spinner spListName;
    RadioGroup rgSearchBy;
    boolean searchByItem = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_item_price);
//      To prevent auto popup of the virtual keyboard
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

//      Initialize the arraylist
        itemId = new ArrayList<>();
        itemList = new ArrayList<>();
        itemPrice = new ArrayList<>();
        itemLocation = new ArrayList<>();
        listId = new ArrayList<>();
        listName = new ArrayList<>();
        uniqueListId = new ArrayList<>();
        uniqueListName = new ArrayList<>();
        autoCompleteitemList = new ArrayList<>();
        autoCompleteLocationList = new ArrayList<>();

//      Setup adapter for the autocompletetextview for the search bar
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, uniqueListName);

//      View declaration
        etSearchItem = findViewById(R.id.etSearchItem);
        lvSearchList = findViewById(R.id.lvSearchList);
        rgSearchBy = findViewById(R.id.rgSearchBy);

//      Set oncheckchangelistener to the radiogroup so the user can choose either to search by item or location
        rgSearchBy.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.rbSearchByItem)
                    searchByItem = true;
                else
                    searchByItem = false;
            }
        });

//      To call the DBHelper class
        helper = new DBHelper(getApplicationContext());

//      To retrieve records from table
        readDB = helper.getReadableDatabase();

        Cursor cursor = readDB.rawQuery("select distinct item_name from listdetails order by item_name", null);
        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                autoCompleteitemList.add(cursor.getString(0));
            }
        }

        cursor = readDB.rawQuery("select distinct location from listdetails order by location", null);
        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                autoCompleteLocationList.add(cursor.getString(0));
            }
        }
//      Setup adapter for the autocompletetextview for the search bar
        searchAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, autoCompleteitemList);
        etSearchItem.setAdapter(searchAdapter);

        cursor = readDB.rawQuery("select * from listdetails order by price", null);
        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                itemId.add(cursor.getString(0));
                itemList.add(cursor.getString(1));
                itemPrice.add(cursor.getString(3));
                listId.add(cursor.getString(5));
                itemLocation.add(cursor.getString(7));
            }
        }

        for(int i=0;i<itemId.size();i++) {
            cursor = readDB.rawQuery("select title from list where id=" + listId.get(i), null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    listName.add(cursor.getString(0));
                }
            }
        }

        cursor = readDB.rawQuery("select * from list", null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                uniqueListId.add(cursor.getString(0));
                uniqueListName.add(cursor.getString(1));
            }
        }
//      Set adapter for the search result list
        lvSearchList.setAdapter(new CompareItemPriceActivity.MyAdapter(CompareItemPriceActivity.this));

//      Set ontextchangedlistener so the search result will update everytime user types a letter
        etSearchItem.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Cursor cursor;
                if(searchByItem) {
                    cursor = readDB.rawQuery("select * from listdetails where item_name like '%" + etSearchItem.getText().toString() + "%' order by price", null);
                    searchAdapter = new ArrayAdapter<>(CompareItemPriceActivity.this, android.R.layout.simple_list_item_1, autoCompleteitemList);
                    etSearchItem.setAdapter(searchAdapter);
                }
                else {
                    cursor = readDB.rawQuery("select * from listdetails where location like '%" + etSearchItem.getText().toString() + "%' order by price", null);
                    searchAdapter = new ArrayAdapter<>(CompareItemPriceActivity.this, android.R.layout.simple_list_item_1, autoCompleteLocationList);
                    etSearchItem.setAdapter(searchAdapter);
                }
                itemId.clear();
                itemList.clear();
                itemPrice.clear();
                listId.clear();
                itemLocation.clear();
                listName.clear();
                if(cursor.getCount()>0){
                    while(cursor.moveToNext()){
                        itemId.add(cursor.getString(0));
                        itemList.add(cursor.getString(1));
                        itemPrice.add(cursor.getString(3));
                        listId.add(cursor.getString(5));
                        itemLocation.add(cursor.getString(7));
                    }
                }

                for(int i=0;i<itemId.size();i++) {
                    cursor = readDB.rawQuery("select title from list where id=" + listId.get(i), null);
                    if (cursor.getCount() > 0) {
                        while (cursor.moveToNext()) {
                            listName.add(cursor.getString(0));
                        }
                    }
                }

                lvSearchList.setAdapter(new CompareItemPriceActivity.MyAdapter(CompareItemPriceActivity.this));
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

//      Set onclicklistener to the search results list so it will display the item details when clicked
        lvSearchList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
//              Dialog view association
                searchItemDetailDialog = new Dialog(CompareItemPriceActivity.this);
                searchItemDetailDialog.setContentView(R.layout.searchitemdetails_layout);

                tvSearchItemNameDetails = searchItemDetailDialog.findViewById(R.id.tvSearchItemNameDetails);
                tvSearchItemPriceDetails = searchItemDetailDialog.findViewById(R.id.tvSearchItemPriceDetails);
                tvSearchItemLocationDetails = searchItemDetailDialog.findViewById(R.id.tvSearchItemLocationDetails);
                btnShowMapSearchDetails = searchItemDetailDialog.findViewById(R.id.btnShowMapSearchDetails);
                spListName = searchItemDetailDialog.findViewById(R.id.spListName);
                btnAddExistingList = searchItemDetailDialog.findViewById(R.id.btnAddExistingList);
                btnCancelSearchItemDetails = searchItemDetailDialog.findViewById(R.id.btnCancelSearchItemDetails);

                spListName.setAdapter(adapter);

                Cursor cursor = readDB.rawQuery("select * from listdetails where item_id="+itemId.get(position), null);
                if(cursor.getCount() > 0){
                    while(cursor.moveToNext()){
                        tvSearchItemNameDetails.setText(cursor.getString(1));
                        tvSearchItemPriceDetails.setText("Price : RM"+cursor.getString(3));
                        location = cursor.getString(7);
                        tvSearchItemLocationDetails.setText("Location : "+location);
                    }
                }

//              Show the location inserted by the user in other map application
                btnShowMapSearchDetails.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Uri uri = Uri.parse("geo:0,0?q="+location);
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(mapIntent);
                    }
                });

//              Add the selected item into the existing list
                btnAddExistingList.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        writeDB = helper.getWritableDatabase();
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("item_name", itemList.get(position));
                        contentValues.put("price", itemPrice.get(position));
                        contentValues.put("quantity", 1);
                        contentValues.put("list_id", uniqueListId.get(spListName.getSelectedItemPosition()));
                        contentValues.put("completed", "No");
                        contentValues.put("location", itemLocation.get(position));
                        long rows = writeDB.insert("listdetails", null, contentValues);
                        if(rows>0) {
                            Toast.makeText(CompareItemPriceActivity.this, "New item has been added!", Toast.LENGTH_LONG).show();
                        }
                    }
                });

//              Close dialog
                btnCancelSearchItemDetails.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        searchItemDetailDialog.dismiss();
                    }
                });

//              Show dialog
                searchItemDetailDialog.show();
//              Set width and height of dialog
                Window window = searchItemDetailDialog.getWindow();
                window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
        });
    }

//  Adapter view association
    public class MyAdapter extends BaseAdapter {
        Context context;
        public MyAdapter(Context context) {
            this.context = context;
        }

        @Override
        public int getCount() {
            return itemId.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tvSearchItemName, tvSearchItemPrice, tvSearchItemLocation, tvSearchItemList;

            if(convertView == null) {
                convertView = LayoutInflater.from(this.context).inflate(R.layout.searchitemlistview_layout, parent, false);
            }

            tvSearchItemName = convertView.findViewById(R.id.tvSearchItemName);
            tvSearchItemPrice = convertView.findViewById(R.id.tvSearchItemPrice);
            tvSearchItemLocation = convertView.findViewById(R.id.tvSearchItemLocation);
            tvSearchItemList = convertView.findViewById(R.id.tvSearchItemList);

            tvSearchItemName.setText(itemList.get(position));
            tvSearchItemPrice.setText("Price : RM"+itemPrice.get(position));
            tvSearchItemLocation.setText("Location : "+itemLocation.get(position));
            tvSearchItemList.setText("Obtained from : "+listName.get(position));

            return convertView;
        }
    }
}
