package com.cwchan.shoppingassistanceapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
//  Variable declaration
    private Context context;
    static String DB_NAME = "testDB";
    static int DB_VERSION = 1;

//  To override the method when the object is created in the other class
    public DBHelper(Context context) {
        super(context,DB_NAME,null,DB_VERSION);
        this.context = context;
    }

//  To create tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table if not exists list (id integer primary key autoincrement," +
                " title varchar(30), create_date varchar(10))");
        db.execSQL("create table if not exists listdetails (item_id integer primary key autoincrement," +
                " item_name varchar(30), description text, price decimal(6,2), quantity integer, list_id integer, completed varchar(3), location text, FOREIGN KEY(list_id) REFERENCES list(id))");
    }

//  To upgrade tables
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists list");
        db.execSQL("drop table if exists listdetails");
        onCreate(db);
    }
}

