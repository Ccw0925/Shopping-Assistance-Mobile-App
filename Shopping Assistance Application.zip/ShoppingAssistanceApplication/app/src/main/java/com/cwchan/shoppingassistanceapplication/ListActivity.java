package com.cwchan.shoppingassistanceapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class ListActivity extends AppCompatActivity {
//  Variable declaration
    DBHelper helper;
    SQLiteDatabase writeDB, readDB;
    ListView lvList;
    TextView tvEmptyListMessage;
    ArrayList<String> listId, list, listTitle, listDate;
    ArrayAdapter adapter;
    String date;
    Dialog addCheckListTitleDialog, editCheckListTitleDialog;
    EditText etListTitle;
    Button btnAdd, btnCancel;
    int pos=-1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

//      Initialize arraylist
        listId = new ArrayList<>();
        list = new ArrayList<>();
        listTitle = new ArrayList<>();
        listDate = new ArrayList<>();

//      View association
        lvList = findViewById(R.id.lvList);
        tvEmptyListMessage = findViewById(R.id.tvEmptyListMessage);

//      To call the DBHelper class
        helper = new DBHelper(getApplicationContext());

//      To retrieve records from table to be added to the arraylist
        readDB = helper.getReadableDatabase();
        Cursor cursor = readDB.rawQuery("select * from list", null);
        if(cursor.getCount()>0){
            while(cursor.moveToNext()){
                listId.add(cursor.getString(0));
                listTitle.add(cursor.getString(1));
                listDate.add(cursor.getString(2));
                list.add("Checklist Name : "+cursor.getString(1)+"\nCreated Date : "+cursor.getString(2));
            }
        }else {
            tvEmptyListMessage.setText("Please click '+' on the top-right corner to add a new checklist!");
        }

        for(int i=0;i<listId.size();i++){
            cursor = readDB.rawQuery("select count(*) from listdetails where list_id="+listId.get(i)+" group by list_id", null);
            if(cursor.getCount()>0){
                while(cursor.moveToNext()){
                    list.set(i, list.get(i)+"\nNumber of items : "+cursor.getString(0));
                }
            }else{
                list.set(i, list.get(i)+"\nNumber of items : "+0);
            }

            cursor = readDB.rawQuery("select count(*) from listdetails where list_id="+listId.get(i)+" and completed='No' group by list_id", null);
            if(cursor.getCount()>0){
                while(cursor.moveToNext()){
                    list.set(i, list.get(i)+"\nNumber of incomplete items : "+cursor.getString(0));
                }
            }else{
                list.set(i, list.get(i)+"\nNumber of incomplete items : "+0);
            }
        }

//      Set adapter to the listview
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        lvList.setAdapter(adapter);

//      Call an intent of listdetailsactivity when the listview is clicked
        lvList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent listDetailsIntent = new Intent(ListActivity.this, ListDetailsActivity.class);
//              Pass the selected list id to listdetailsactivity
                listDetailsIntent.putExtra("listid", Integer.valueOf(listId.get(position)));
                startActivity(listDetailsIntent);
            }
        });

//      Register listview for context menu
        registerForContextMenu(lvList);
    }

//  Create context menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.context_menu, menu);
        AdapterView.AdapterContextMenuInfo acmi = (AdapterView.AdapterContextMenuInfo) menuInfo;
        pos = acmi.position;
    }

//  Determine the action when an item in context menu is selected
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int option = item.getItemId();
        switch(option){
//          Show edit dialog for the user to edit the list title
            case R.id.cm_edit:
                editCheckListTitleDialog = new Dialog(ListActivity.this);
                editCheckListTitleDialog.setContentView(R.layout.addnewlist_layout);
                etListTitle = editCheckListTitleDialog.findViewById(R.id.etListTitle);
                etListTitle.setText(listTitle.get(pos));
                btnAdd = editCheckListTitleDialog.findViewById(R.id.btnAdd);
                btnAdd.setText("Save");
                btnAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        writeDB = helper.getWritableDatabase();
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("title", etListTitle.getText().toString());
                        long rows = writeDB.update("list", contentValues, "id=?", new String[]{listId.get(pos)});
                        if(rows>0) {
                            Toast.makeText(ListActivity.this, "A checklist has been updated!", Toast.LENGTH_LONG).show();
                            listTitle.set(pos, etListTitle.getText().toString());
                            list.set(pos, "Checklist Name : "+etListTitle.getText().toString()+"\nCreated Date : "+listDate.get(pos));
                            lvList.setAdapter(adapter);
                        }
                        else
                            Toast.makeText(ListActivity.this, "Failed to update record!", Toast.LENGTH_LONG).show();

                        readDB = helper.getReadableDatabase();
                        Cursor cursor = readDB.rawQuery("select count(*) from listdetails where list_id="+listId.get(pos)+" group by list_id", null);
                        if(cursor.getCount()>0){
                            while(cursor.moveToNext()){
                                list.set(pos, list.get(pos)+"\nNumber of items : "+cursor.getString(0));
                            }
                        }else{
                            list.set(pos, list.get(pos)+"\nNumber of items : "+0);
                        }

                        cursor = readDB.rawQuery("select count(*) from listdetails where list_id="+listId.get(listId.size()-1)+" and completed='No' group by list_id", null);
                        if(cursor.getCount()>0){
                            while(cursor.moveToNext()){
                                list.set((listId.size()-1), list.get(listId.size()-1)+"\nNumber of incomplete items : "+cursor.getString(0));
                            }
                        }else{
                            list.set((listId.size()-1), list.get(listId.size()-1)+"\nNumber of incomplete items : "+0);
                        }

                        editCheckListTitleDialog.dismiss();
                    }
                });
                btnCancel = editCheckListTitleDialog.findViewById(R.id.btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        editCheckListTitleDialog.dismiss();
                    }
                });
                editCheckListTitleDialog.show();
                break;
//          Delete the selected list
            case R.id.cm_delete:
                AlertDialog deleteDialogBox = AskOption();
                deleteDialogBox.show();
                break;
        }
        return super.onContextItemSelected(item);
    }

//  Create option menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_mainmenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

//  Determine the action when an item in option menu is selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int option = item.getItemId();
        switch(option){
//          Show add dialog for the user to add new list
            case R.id.mm_add:
//              Get current date to be added to the list
                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                date = dateFormat.format(calendar.getTime());

                addCheckListTitleDialog = new Dialog(ListActivity.this);
                addCheckListTitleDialog.setContentView(R.layout.addnewlist_layout);
                etListTitle = addCheckListTitleDialog.findViewById(R.id.etListTitle);
                etListTitle.setText("List "+(list.size()+1));
                btnAdd = addCheckListTitleDialog.findViewById(R.id.btnAdd);
                btnAdd.setText("Add");
                btnAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        writeDB = helper.getWritableDatabase();
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("title", etListTitle.getText().toString());
                        contentValues.put("create_date", date);
                        long rows = writeDB.insert("list", null, contentValues);
                        if(rows>0) {
                            Toast.makeText(ListActivity.this, rows + " record(s) added!", Toast.LENGTH_LONG).show();
                            listTitle.add(etListTitle.getText().toString());
                            listDate.add(date);
                            list.add("Checklist Name : "+etListTitle.getText().toString()+"\nCreated Date : "+date);
                            lvList.setAdapter(adapter);
                            tvEmptyListMessage.setText("");
                        }
                        else
                            Toast.makeText(ListActivity.this, "Failed to add record!", Toast.LENGTH_LONG).show();

                        listId.clear();

                        Cursor cursor = readDB.rawQuery("select id from list", null);
                        if(cursor.getCount()>0){
                            while(cursor.moveToNext()){
                                listId.add(cursor.getString(0));
                            }
                        }else {
                            Toast.makeText(ListActivity.this, "No record found!", Toast.LENGTH_LONG).show();
                        }

                        cursor = readDB.rawQuery("select count(*) from listdetails where list_id="+listId.get(listId.size()-1)+" group by list_id", null);
                        if(cursor.getCount()>0){
                            while(cursor.moveToNext()){
                                list.set((listId.size()-1), list.get(listId.size()-1)+"\nNumber of items : "+cursor.getString(0));
                            }
                        }else{
                            list.set((listId.size()-1), list.get(listId.size()-1)+"\nNumber of items : "+0);
                        }

                        cursor = readDB.rawQuery("select count(*) from listdetails where list_id="+listId.get(listId.size()-1)+" and completed='No' group by list_id", null);
                        if(cursor.getCount()>0){
                            while(cursor.moveToNext()){
                                list.set((listId.size()-1), list.get(listId.size()-1)+"\nNumber of incomplete items : "+cursor.getString(0));
                            }
                        }else{
                            list.set((listId.size()-1), list.get(listId.size()-1)+"\nNumber of incomplete items : "+0);
                        }

                        addCheckListTitleDialog.dismiss();
                    }
                });
                btnCancel = addCheckListTitleDialog.findViewById(R.id.btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        addCheckListTitleDialog.dismiss();
                    }
                });
                addCheckListTitleDialog.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

//  To refresh the listview when this activity is resumed
    @Override
    protected void onResume() {
        super.onResume();
        listId = new ArrayList<>();
        list = new ArrayList<>();
        listTitle = new ArrayList<>();
        listDate = new ArrayList<>();

        readDB = helper.getReadableDatabase();
        Cursor cursor = readDB.rawQuery("select * from list", null);
        if(cursor.getCount()>0){
            while(cursor.moveToNext()){
                listId.add(cursor.getString(0));
                listTitle.add(cursor.getString(1));
                listDate.add(cursor.getString(2));
                list.add("Checklist Name : "+cursor.getString(1)+"\nCreated Date : "+cursor.getString(2));
            }
        }else {
            tvEmptyListMessage.setText("Please click '+' on the top-right corner to add a new checklist!");
        }

        for(int i=0;i<listId.size();i++){
            cursor = readDB.rawQuery("select count(*) from listdetails where list_id="+listId.get(i)+" group by list_id", null);
            if(cursor.getCount()>0){
                while(cursor.moveToNext()){
                    list.set(i, list.get(i)+"\nNumber of items : "+cursor.getString(0));
                }
            }else{
                list.set(i, list.get(i)+"\nNumber of items : "+0);
            }

            cursor = readDB.rawQuery("select count(*) from listdetails where list_id="+listId.get(i)+" and completed='No' group by list_id", null);
            if(cursor.getCount()>0){
                while(cursor.moveToNext()){
                    list.set(i, list.get(i)+"\nNumber of incomplete items : "+cursor.getString(0));
                }
            }else{
                list.set(i, list.get(i)+"\nNumber of incomplete items : "+0);
            }
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        lvList.setAdapter(adapter);
    }

//  Show delete confirmation dialog box
    private AlertDialog AskOption()
    {
        AlertDialog myQuittingDialogBox = new AlertDialog.Builder(this)
                // set message, title, and icon
                .setTitle("Delete")
                .setMessage("Are you sure you want to delete?")

                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        writeDB = helper.getWritableDatabase();
                        writeDB.delete("listdetails", "list_id=?", new String[]{listId.get(pos)});
                        writeDB = helper.getWritableDatabase();
                        long rowscount = writeDB.delete("list", "id=?", new String[]{listId.get(pos)});
                        if(rowscount>0) {
                            Toast.makeText(ListActivity.this, "List has been deleted!", Toast.LENGTH_LONG).show();
                            listId.remove(pos);
                            listTitle.remove(pos);
                            listDate.remove(pos);
                            list.remove(pos);
                            lvList.setAdapter(adapter);
                        } else {
                            Toast.makeText(ListActivity.this, " Failed to delete!", Toast.LENGTH_LONG).show();
                        }

                        if(listId.size()<=0)
                            tvEmptyListMessage.setText("Please click '+' on the top-right corner to add a new checklist!");
                        dialog.dismiss();
                    }

                })
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();

                    }
                })
                .create();

        return myQuittingDialogBox;
    }
}
