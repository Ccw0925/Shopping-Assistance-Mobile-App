package com.cwchan.shoppingassistanceapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

//  Variables declaration
    ImageView ivSplashLogo;
    TextView tvSplashTitle;
    Button btnGetStarted;
    Animation frombottom, fromtop;
    Notification notification;
    NotificationManager nm;
    DBHelper helper;
    SQLiteDatabase readDB;
    int incompleteItemCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//      View Association
        btnGetStarted = findViewById(R.id.btnGetStarted);
        ivSplashLogo = findViewById(R.id.ivSplashLogo);
        tvSplashTitle = findViewById(R.id.tvSplashTitle);

//      Animations for the button
        frombottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);
        fromtop = AnimationUtils.loadAnimation(this, R.anim.fromtop);

//      Setting up the animation
        btnGetStarted.setAnimation(frombottom);
        ivSplashLogo.setAnimation(fromtop);
        tvSplashTitle.animate().alpha(1f).setDuration(2000);

//      Call intent to the HomeActivity
        btnGetStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });
    }

//  To show the notification when the application is closed
    @Override
    protected void onDestroy() {
//      To call the DBHelper class
        helper = new DBHelper(getApplicationContext());

//      To retrieve records from listdetails table to get incomplete items count
        readDB = helper.getReadableDatabase();
        Cursor cursor = readDB.rawQuery("select count(*) from listdetails where completed='No'", null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                incompleteItemCount = cursor.getInt(0);
            }
        }

        if(incompleteItemCount>0) {
//          Building the notification
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                NotificationChannel nc = new NotificationChannel("code", "My App", NotificationManager.IMPORTANCE_HIGH);
                nc.setDescription("My Channel");
                nc.enableLights(true);
                nc.setLightColor(Color.RED);
                nc.enableVibration(true);
                nc.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
                nc.setShowBadge(false);
                nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.createNotificationChannel(nc);
            }

            Notification.Builder nb = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                nb = new Notification.Builder(MainActivity.this, "code");
            }

            nb.setContentTitle("Incomplete Items");
            nb.setContentText("You have " + incompleteItemCount + " items that have not complete yet.");
            nb.setSmallIcon(R.drawable.icon_logo);
            nb.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.icon_logo));

            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(MainActivity.this, 101, intent, PendingIntent.FLAG_CANCEL_CURRENT);
            nb.setContentIntent(pendingIntent);
            nb.setAutoCancel(true);
            notification = nb.build();
            nm.notify(101, notification);
        }
        super.onDestroy();
    }
}
