package com.cwchan.shoppingassistanceapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class CalculatorActivity extends AppCompatActivity {
//  Variable declaration
    EditText etPriceCalculator, etUnit;
    TextView tvResult;
    Button btnCalculate;
    Spinner spUnit;
    double price, unit, result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

//      View association
        etPriceCalculator = findViewById(R.id.etPriceCalculator);
        etUnit = findViewById(R.id.etUnit);
        tvResult = findViewById(R.id.tvResult);
        btnCalculate = findViewById(R.id.btnCalculate);
        spUnit = findViewById(R.id.spUnit);

//      Set clicklistener to the button so it will return output when clicked
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                price = Double.valueOf(etPriceCalculator.getText().toString());
                unit = Double.valueOf(etUnit.getText().toString());
                result = unit / price;
                tvResult.setText("RM1 can buy "+(Math.round(result * 1000.0) / 1000.0)+" "+spUnit.getSelectedItem().toString());
            }
        });
    }
}
