package com.cwchan.shoppingassistanceapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {
//  Variables declaration
    static String[] homeMenu = {"CheckList", "Items Comparison", "Unit Calculator"};
    static int[] imageArray = {R.drawable.checklist_transparent, R.drawable.search_transparent, R.drawable.calculator_transparent};
    GridView gvHomeMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

//      View association
        gvHomeMenu = findViewById(R.id.gvHomeMenu);

//      Set adapter to the gridview so it will show all menus
        gvHomeMenu.setAdapter(new MyAdapter(HomeActivity.this));
//      Set clicklistener so it will call intent to the corresponding activity when clicked
        gvHomeMenu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();

                switch (position){
                    case 0:
                        intent = new Intent(HomeActivity.this, ListActivity.class);
                        break;
                    case 1:
                        intent = new Intent(HomeActivity.this, CompareItemPriceActivity.class);
                        break;
                    case 2:
                        intent = new Intent(HomeActivity.this, CalculatorActivity.class);
                        break;
                }

                startActivity(intent);
            }
        });
    }

//  Adapter view association
    public class MyAdapter extends BaseAdapter {
        Context context;
        public MyAdapter(Context context) {
            this.context = context;
        }

        @Override
        public int getCount() {
            return homeMenu.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tvMenuTitle;
            ImageView ivMenuIcon;

            if(convertView == null) {
                convertView = LayoutInflater.from(this.context).inflate(R.layout.homemenugridview_layout, parent, false);
            }

            tvMenuTitle = convertView.findViewById(R.id.tvMenuTitle);
            ivMenuIcon = convertView.findViewById(R.id.ivMenuIcon);

            tvMenuTitle.setText(homeMenu[position]);
            ivMenuIcon.setImageResource(imageArray[position]);

            return convertView;
        }
    }
}
